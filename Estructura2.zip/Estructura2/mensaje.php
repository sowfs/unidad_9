<?php
if (isset($_POST["submit"])) {
	
$para = "Topflix@gmail.com";
$asunto= "Mensaje desde el sitio de Cupcakes";
$nombre= $_POST["nombre"];
$correo= $_POST["correo"];
$mensaje= $_POST["mensaje"];

	$cuerpo= "Enviado por $nombre\n E-Mail: $correo\n $check_msg Mensaje:\n";
	
	echo "Mensaje enviado $para!";
	mail($para, $asunto, $cuerpo);
	}else{
	echo "Ups, algo salió mal con el envío";
	}
?>